package com.example.praktikum.telurasinarnis.model;

import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.praktikum.telurasinarnis.HalamanAwal;
import com.example.praktikum.telurasinarnis.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TelorAsinData {

    public static String[][] data = new String[][]{
            {"Telur Asin Matang", "3000", "https://pbs.twimg.com/media/EEq_i1TUcAAdIGQ?format=png&name=240x240","100"},
            {"Telur Asin Mentah", "2500", "https://pbs.twimg.com/media/EEq_i1TUcAErCmP?format=png&name=240x240","100"},
            {"Telur Asin Merah", "3500", "https://pbs.twimg.com/media/EEq_i1SUcAEMqYD?format=png&name=240x240","100"},
            {"Telur Bebek", "1500", "https://pbs.twimg.com/media/EEq_i1UUwAobwLi?format=png&name=240x240","100"}
    };

    public static ArrayList<TelorAsin> getListData(){


        ArrayList<TelorAsin> list = new ArrayList<>();

        for (String[] aData : data){
            TelorAsin telorAsin = new TelorAsin();
            telorAsin.setNama(aData[0]);
            telorAsin.setHarga(aData[1]);
            telorAsin.setPhoto(aData[2]);
            telorAsin.setStok(aData[3]);
            list.add(telorAsin);
        }
        return list;
    }
}
