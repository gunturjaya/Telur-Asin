package com.example.praktikum.telurasinarnis;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.praktikum.telurasinarnis.R;

public class ContactUsActivity extends AppCompatActivity {
    ImageView imgProfile;
    TextView nameProfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        ActionBar actionBar = getSupportActionBar(); // or getActionBar();
        getSupportActionBar().setTitle("Contact Us");
        String title = actionBar.getTitle().toString();


        imgProfile = (ImageView) findViewById(R.id.profile_image);
        nameProfile = (TextView) findViewById(R.id.profile_name);
    }
}
