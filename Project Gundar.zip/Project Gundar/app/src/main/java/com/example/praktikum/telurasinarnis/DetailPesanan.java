package com.example.praktikum.telurasinarnis;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.praktikum.telurasinarnis.model.Pesanan;
import com.example.praktikum.telurasinarnis.model.Stok;
import com.example.praktikum.telurasinarnis.model.TelorAsin;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static android.text.TextUtils.isEmpty;

public class DetailPesanan extends AppCompatActivity {
    private TextView tvNama, tvJudul, tvMessage, tvHarga, tvTotalHarga, tvJumlahBanyak;
    private ImageView imgPhoto, imgPopUp;
    private EditText edtNama, edtAlamat, edtNoHp;
    private Button btnPesan, btnOk;
    private String getUserID;
    private FirebaseAuth auth;
    private DatabaseReference getReference;
    private DatabaseReference getStokTelor;
    private int RC_SIGN_IN = 1, jumlah=1;
    private Intent b = this.getIntent();
    private ArrayList<TelorAsin> listTelorAsin;
    Dialog epicDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pesanan);
        ActionBar actionBar = getSupportActionBar();
        getSupportActionBar().setTitle("Pesan");
        String title = actionBar.getTitle().toString();


        tvTotalHarga = (TextView) findViewById(R.id.tv_totalharga);
        tvHarga = (TextView) findViewById(R.id.tv_detail_harga);
        tvNama = (TextView) findViewById(R.id.tv_detail_name);
        imgPhoto = (ImageView) findViewById(R.id.img_detail_photo);
        edtNama = (EditText) findViewById(R.id.edt_nama);
        edtAlamat = (EditText) findViewById(R.id.edt_alamat);
        edtNoHp = (EditText) findViewById(R.id.edt_nohp);
        btnPesan = (Button) findViewById(R.id.btn_pesan);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        auth = FirebaseAuth.getInstance();

        getReference = database.getReference("Admin");

        epicDialog = new Dialog(this);
        Intent i = this.getIntent();

        String images = i.getExtras().getString("IMAGES_KEY");
        String name = i.getExtras().getString("NAMA_KEY");
        String stoktelor = i.getExtras().getString("KEY_TELOR");
        String harga = i.getExtras().getString("HARGA_KEY");
        getStokTelor = database.getReference("Stok").child(stoktelor);

        imgPhoto.setImageURI(Uri.parse(images));
        tvNama.setText(name);
        tvHarga.setText("Rp. "+harga+"/pc");
        tvTotalHarga.setText("Rp. " + harga);
        Glide.with(this)
                .load(images)
                .into(imgPhoto);

        btnPesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addPesanan();

                //showPopUpOrder();
                //Intent intent = new Intent(DetailPesanan.this, HalamanAwal.class);
                //startActivity(intent);
            }
        });
    }

    public void Tambah(View view){
        if(jumlah == 20){
            Toast.makeText(this, "Pesanan maksimal 20", Toast.LENGTH_SHORT).show();
            return;
        }
        jumlah=jumlah+1;
        display(jumlah);
        TotHar();
    }
    public void Kurang(View view){
        if(jumlah == 1){
            Toast.makeText(this, "Pesanan minimal 1", Toast.LENGTH_SHORT).show();
            return;
        }
        jumlah=jumlah-1;
        display(jumlah);
        TotHar();
    }
    public void display(int angka){
        tvJumlahBanyak = (TextView) findViewById(R.id.tvJumlah);
        tvJumlahBanyak.setText("" + angka);
    }
    public int TotHar(){
        int harga=0;
        if(tvNama.getText().equals("Telur Asin Matang")){
            harga=2500;
        }else if(tvNama.getText().equals("Telur Asin Mentah")){
            harga=3000;
        }else if(tvNama.getText().equals("Telur Asin Merah")){
            harga=2000;
        }else if(tvNama.getText().equals("Telur Bebek")){
            harga=3000;
        }
        int total= jumlah * harga;
        tvTotalHarga.setText("Rp. " + total);
        return total;
    }

    private void addPesanan(){
        String pesanan = tvNama.getText().toString().trim();
        String nama = edtNama.getText().toString().trim();
        String alamat = edtAlamat.getText().toString().trim();
        String nohp = edtNoHp.getText().toString().trim();
        String jumlah = tvJumlahBanyak.getText().toString().trim();
        String totalhrg = tvTotalHarga.getText().toString().trim();

        if(!TextUtils.isEmpty(pesanan)&&!TextUtils.isEmpty(nama)&&!TextUtils.isEmpty(alamat)&&!TextUtils.isEmpty(nohp)&&!TextUtils.isEmpty(jumlah)){
            String idPesanan = getReference.push().getKey();
            Pesanan mPesanan = new Pesanan(idPesanan,pesanan, nama, alamat, nohp, jumlah, totalhrg);
            getUserID = auth.getCurrentUser().getUid();
            getReference.child(getUserID).child(idPesanan)
                    .setValue(mPesanan);
            Toast.makeText(DetailPesanan.this, "Pesanan Anda Berhasil dibuat", Toast.LENGTH_SHORT).show();

            epicDialog.setContentView(R.layout.popup_order);
            imgPopUp = (ImageView) epicDialog.findViewById(R.id.img_popup_order);
            btnOk = (Button) epicDialog.findViewById(R.id.btnOkey);
            tvJudul = (TextView) epicDialog.findViewById(R.id.tvJudul);
            tvMessage = (TextView) epicDialog.findViewById(R.id.tvMessage);

            epicDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            epicDialog.show();

            /*String name = i.getExtras().getString("NAMA_KEY");
            for (int j = 0; j>3;j++){
                TelorAsin telorAsin =listTelorAsin.get(j);
                if(name.equalsIgnoreCase(telorAsin.getNama())) {
                    int a = Integer.parseInt(telorAsin.getStok())- Integer.parseInt(jumlah);
                telorAsin.setStok(String.valueOf(a));
                }
            }*/
            btnOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   Intent intent = new Intent(DetailPesanan.this, HalamanAwal.class);
                    startActivity(intent);
                    finish();
                }
            });
        }else{
            Toast.makeText(DetailPesanan.this, "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
        }

    }
}
