package com.example.praktikum.telurasinarnis;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.praktikum.telurasinarnis.model.Pesanan;
import com.example.praktikum.telurasinarnis.model.RiwayatList;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RiawayatActivity extends AppCompatActivity {
    FirebaseAuth auth;
    DatabaseReference getReference;
    String getUserID;
    ListView listViewRiwayat;
    List<Pesanan> pesananList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riawayat);

        ActionBar actionBar = getSupportActionBar();
        getSupportActionBar().setTitle("Riwayat");
        String title = actionBar.getTitle().toString();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        auth = FirebaseAuth.getInstance();
        getReference = database.getReference("Admin");
        listViewRiwayat = (ListView) findViewById(R.id.listViewRiwayat);
        pesananList = new ArrayList<>();
        onStart();
    }

    @Override
    protected void onStart() {
        super.onStart();
        getUserID = auth.getCurrentUser().getUid();

        getReference.child(getUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                pesananList.clear();

                for (DataSnapshot riwayatSnapshot : dataSnapshot.getChildren()){
                    Pesanan pesanan = riwayatSnapshot.getValue(Pesanan.class);
                    pesananList.add(pesanan);
                }
                RiwayatList adapter = new RiwayatList(RiawayatActivity.this, pesananList);
                listViewRiwayat.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
