package com.example.praktikum.telurasinarnis;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.praktikum.telurasinarnis.adapter.CardViewAdapter;
import com.example.praktikum.telurasinarnis.model.TelorAsin;
import com.example.praktikum.telurasinarnis.model.TelorAsinData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class HalamanAwal extends AppCompatActivity {
    private RecyclerView rvTelorAsin;
    private FloatingActionButton fab;
    private static final int TIME_INTERVAL = 2000; private long mBackPressed;


    private ArrayList<TelorAsin> list = new ArrayList<>();

    /**
     * Called when the activity has detected the user's press of the back
     * key. The {@link #getOnBackPressedDispatcher() OnBackPressedDispatcher} will be given a
     * chance to handle the back button before the default behavior of
     * {@link Activity#onBackPressed()} is invoked.
     *
     * @see #getOnBackPressedDispatcher()
     */
    @Override
    public void onBackPressed() {
        if (mBackPressed + TIME_INTERVAL > System.currentTimeMillis()) {
            super.onBackPressed();
            return;
        } else {
            Toast.makeText(getBaseContext(), "Tekan Back Sekali lagi untuk Keluar", Toast.LENGTH_SHORT).show();
        } mBackPressed = System.currentTimeMillis();
        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(startMain);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_awal);

        ActionBar actionBar = getSupportActionBar();
        getSupportActionBar().setTitle("Telur Asin Arnis");
        String title = actionBar.getTitle().toString();

        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i =  new Intent(HalamanAwal.this, RiawayatActivity.class);
                startActivity(i);
            }
        });
        rvTelorAsin = findViewById(R.id.rv_listTelor);
        rvTelorAsin.setHasFixedSize(true);
        list.addAll(TelorAsinData.getListData());
        showRecyclerCardView();
    }
    private void showRecyclerCardView(){
        rvTelorAsin.setLayoutManager(new LinearLayoutManager(this ));
        CardViewAdapter cardViewAdapter = new CardViewAdapter(list, this);
        rvTelorAsin.setAdapter(cardViewAdapter);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.item_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==R.id.contactUs){
            Intent i = new Intent(this, ContactUsActivity.class);
            startActivity(i);
        }else if (item.getItemId()==R.id.logout){
            SharedPreferences sharedpreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.clear();
            editor.apply();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setMode(int itemId) {

    }
}
