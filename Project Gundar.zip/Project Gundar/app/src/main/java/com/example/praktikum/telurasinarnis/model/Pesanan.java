package com.example.praktikum.telurasinarnis.model;

public class Pesanan {
    private String idPesanan;
    private String pesanan;
    private String namaPemesan;
    private String noHp;
    private String alamat;
    private String jumlah;
    private String totalHarga;


    public Pesanan(){

    }
    public Pesanan(String idPesanan, String pesanan, String namaPemesan, String alamat, String noHp, String jumlah, String totalHarga){
        this.idPesanan = idPesanan;
        this.namaPemesan = namaPemesan;
        this.pesanan = pesanan;
        this.alamat = alamat;
        this.noHp = noHp;
        this.jumlah = jumlah;
        this.totalHarga = totalHarga;

    }

    public String getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(String totalHarga) {
        this.totalHarga = totalHarga;
    }

    public String getIdPesanan() {
        return idPesanan;
    }

    public void setIdPesanan(String idPesanan) {
        this.idPesanan = idPesanan;
    }

    public String getPesanan() {
        return pesanan;
    }

    public void setPesanan(String pesanan) {
        this.pesanan = pesanan;
    }

    public String getNamaPemesan() {
        return namaPemesan;
    }

    public void setNamaPemesan(String namaPemesan) {
        this.namaPemesan = namaPemesan;
    }

    public String getNoHp() {
        return noHp;
    }

    public void setNoHp(String noHp) {
        this.noHp = noHp;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }
}
