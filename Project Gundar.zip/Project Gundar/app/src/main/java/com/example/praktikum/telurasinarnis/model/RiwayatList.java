package com.example.praktikum.telurasinarnis.model;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.praktikum.telurasinarnis.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

import java.util.List;

public class RiwayatList extends ArrayAdapter<Pesanan> {

    private Activity context;
    private List<Pesanan> pesananList;
    DatabaseReference getReference;

    public RiwayatList(Activity context, List<Pesanan> pesananList){
        super(context, R.layout.item_riwayat, pesananList);
        this.context = context;
        this.pesananList = pesananList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        getReference = database.getReference("Stok");

        View listViewItem = inflater.inflate(R.layout.item_riwayat, null, true);

        TextView tvNamaPesanan = (TextView) listViewItem.findViewById(R.id.tvNamaPesananRiwayat);
        TextView tvNamaPemesan = (TextView) listViewItem.findViewById(R.id.tvNamaPemesanRiwayat);
        TextView tvAlamat = (TextView) listViewItem.findViewById(R.id.tvAlamatRiwayat);
        TextView tvNohp = (TextView) listViewItem.findViewById(R.id.tvNoHpRiwayat);
        TextView tvJumlah = (TextView) listViewItem.findViewById(R.id.tvJumlahRiwayat);
        TextView tvTotalHarga = (TextView) listViewItem.findViewById(R.id.tvTotalhrgRiwayat);

        Pesanan pesanan = pesananList.get(position);
        tvNamaPesanan.setText(pesanan.getPesanan());
        tvNamaPemesan.setText(pesanan.getNamaPemesan());
        tvAlamat.setText(pesanan.getAlamat());
        tvNohp.setText(pesanan.getNoHp());
        tvJumlah.setText(pesanan.getJumlah());
        tvTotalHarga.setText(pesanan.getTotalHarga());

        return listViewItem;
    }
}
