package com.example.praktikum.telurasinarnis.model;

public class TelorAsin {
    private String nama;
    private String harga;
    private String photo;
    private String stok;
    public String getStok() {
        return stok;
    }

    public void setStok(String stok) {
        this.stok = stok;
    }



    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }


}
