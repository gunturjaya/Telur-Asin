package com.example.praktikum.telurasinarnis.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.praktikum.telurasinarnis.DetailPesanan;
import com.example.praktikum.telurasinarnis.HalamanAwal;
import com.example.praktikum.telurasinarnis.R;
import com.example.praktikum.telurasinarnis.model.Stok;
import com.example.praktikum.telurasinarnis.model.TelorAsin;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CardViewAdapter extends RecyclerView.Adapter<CardViewAdapter.CardViewHolder> {
    private ArrayList<TelorAsin> listTelorAsin;
    private ArrayList<Stok> listStock;
    Context c;
    List<Stok> stokList;
    TextView tvStok;
    DatabaseReference databaseReference;

    public CardViewAdapter(ArrayList<TelorAsin> list, Context c){
        this.listTelorAsin=list;

        this.c=c;
    }
    @NonNull
    @Override
    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_telorasin, viewGroup, false);
        return new CardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CardViewHolder cardViewHolder, final int i) {

        stokList = new ArrayList<>();
        TelorAsin telorAsin =listTelorAsin.get(i);
        final String images = telorAsin.getPhoto();
        final String name = telorAsin.getNama();
        final String hrg = telorAsin.getHarga();
        Glide.with(cardViewHolder.itemView.getContext())
                .load(telorAsin.getPhoto())
                .apply(new RequestOptions().override(100,100))
                .into(cardViewHolder.imgPhoto);
        cardViewHolder.tvNama.setText(telorAsin.getNama());
        cardViewHolder.tvHarga.setText("Rp. " +telorAsin.getHarga() + "/pc");
        cardViewHolder.tvStok.setText("Stok : "+telorAsin.getStok());
        cardViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDetail(images, name, hrg, i);
                Toast.makeText(cardViewHolder.itemView.getContext(), "Kamu Memilih " + listTelorAsin.get(cardViewHolder.getAdapterPosition()).getNama(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void openDetail(String images, String name, String hrg, int posisi){

        Intent intent = new Intent(c, DetailPesanan.class);
        String telor = "";

        intent.putExtra("IMAGES_KEY", images);
        intent.putExtra("NAMA_KEY", name);
        intent.putExtra("HARGA_KEY", hrg);
        intent.putExtra("POSISI",posisi);


        intent.putExtra("KEY_TELOR",telor);
        c.startActivity(intent);
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return listTelorAsin.size();
    }

     class CardViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView tvNama,tvHarga,tvStok;


         CardViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.img_item_photo);
            tvNama  = itemView.findViewById(R.id.tv_item_name);
            tvHarga = itemView.findViewById(R.id.tv_item_harga);
            tvStok = itemView.findViewById(R.id.tv_item_stok);
        }
    }
}
