package com.example.praktikum.telurasinarnis.model;

public class Stok {
    private String banyak;
    public String getBanyak() {
        return banyak;
    }

    public void setBanyak(String banyak) {
        this.banyak = banyak;
    }
    public Stok(){

    }


    public Stok(String banyak) {
        this.banyak = banyak;
    }
}